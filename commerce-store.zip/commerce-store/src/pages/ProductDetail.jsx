import { ShoppingBag } from "lucide-react";
import React from "react";
import { Link, useParams } from "react-router-dom";
import products from "../productsContent";

function ProductDetail() {

    const {id} = useParams();
   
// to match id details
    const product = products.find((p) => p.id === parseInt(id));

    if(!product){
        return <div className="relative w-[1440px] h-[1024px] bg-[rgba(237,237,237,1)] rounded-[16px]">
            <div className="text-center">
                <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
                <Link to="/" className="text-blue-600">Return Home</Link>
            </div>
        </div>
    }

  return (
    <div className="relative w-[1440px] h-[1024px] bg-[rgba(237,237,237,1)] rounded-[16px]">
      <div>
        <Link to="/" className="flex flex-row justify-center items-center p-2 gap-2 w-[88px] h-[40px] rounded-[10px] flex-none order-0 grow-0
">
          Back
        </Link>
      </div>

      {/* The grid on how the layout is */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div className="flex flex-row items-start p-2 gap-4 w-[80px] h-[80px] flex-none order-0 grow-0 bg-white rounded-[12px] ">
          {/* The image of the product, to the person styling:please resize image to make it not to big and fit right */}
          <img src={product.image} alt={product.title} className="w-[64px] h-[64px] flex-none order-0 grow-0" />
        </div>

        {/* The product Title, Price and Description */}
        <div>
            {/* Product Title */}
          <h1 className="w-[110px] h-[24px] font-Cabin not-italic font-medium text-xl leading-6 text-[rgb(26,31,22)] flex-none order-0 grow-0">{product.title}</h1>
          {/* Product Category */}
          <p className="w-[72px] h-[19px] font-Cabin not-italic font-medium text-base leading-[19px] tracking-[-0.02em] text-[rgba(96,105,92,1)] flex-none order-1 grow-0">{product.category}</p>
          {/* Product Price */}
          <div className="flex flex-row justify-between items-center p-4 gap-[10px] w-[175.36px] h-[50px] flex-none order-2 grow-0 self-stretch">
            <span className="mx-auto w-[76px] h-[24px] font-Cabin not-italic font-medium text-xl leading-6 text-[rgba(96,105,92,1)] flex-none order-none grow-0">${product.price}</span>
             {/* Product Description */}
          <p className="w-[72px] h-[19px] font-cabin not-italic font-normal text-base leading-[19px] tracking-[-0.02em] text-[rgba(96,105,92,1)] flex-none order-1 grow-0">{product.description}</p>
          </div>

          {/* The Add to bag Button */}
          <button className="flex flex-row justify-center items-center px-6 py-2 gap-2 w-[174px] h-[40px] bg-[#1A1F16] rounded-[14px] flex-none order-0 grow-0">
            <ShoppingBag /> Add to bag
          </button>
        </div>
        <div className="">
          {/* Description, to the person styling: It needs to be centered and add a top border line with light gray, for example: border-gray-400 */}
          <h1 className="w-[153px] h-[38px] font-cabin not-italic font-medium text-[31.25px] leading-[38px] text-[#1A1F16] flex-none order-0 grow-0">Description</h1>
          <p className="font-Cabin not-italic font-normal text-[20px] leading-[6px] text-[#1A1F16] w-[509.34px] h-[106px] flex-none order-0 grow self-stretch ">Discover a premium selection of modern tech designed to elevate your everyday life — from powerful smartphones to stylish wearables and high-quality audio gear. Each product in our collection has been carefully chosen for its exceptional performance, reliability, and sleek aesthetic that suits any lifestyle. Whether you're upgrading to a faster iPhone with stunning cameras and impressive battery life, stepping into the world of smart convenience with an Apple Watch designed to keep you connected and active, or immersing yourself in rich, detailed sound with lightweight Sony headphones, our range offers the perfect combination of innovation and comfort. Built to deliver seamless efficiency, these devices blend advanced technology with user-friendly design, making them ideal for work, entertainment, fitness, and everyday connectivity. No matter which device you choose, you’re selecting a product crafted to enhance productivity, simplify your routines, and complement your personal style with elegance and durability.</p>
        </div>
      </div>
    </div>
  );
}

export default ProductDetail;