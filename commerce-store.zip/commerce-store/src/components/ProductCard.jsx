import React from 'react'
import {Link} from 'react-router-dom'

function ProductCard({ product }){
  return (
    // Link makes it responsive so that when clicked, it goes to product description
    <Link to={`/product/${product.id}`}>
    <div className='shadow-lg rounded-md cursor-pointer'>
      <img src={product.image} alt="" />
      <div className='bg-gray-50 p-4'>
        <h2 className='w-[110px] h-[24px] font-Cabin not-italic font-medium text-xl leading-6 text-[rgb(26,31,22)] flex-none order-0 grow-0'>{product.title}</h2>
        <p className='w-[72px] h-[19px] font-cabin not-italic font-normal text-base leading-[19px] tracking-[-0.02em] text-[rgba(96,105,92,1)] flex-none order-1 grow-0'>{product.description}</p>
        <div className='flex justify-between mt-4 items-center'>
          <p className='flex flex-row justify-between items-center p-4 gap-[10px] w-[175.36px] h-[50px] flex-none order-2 grow-0 self-stretch'>${product.price}</p>
          <p>View Details</p>
        </div>
      </div>
    </div>
    </Link>
  )
}

export default ProductCard